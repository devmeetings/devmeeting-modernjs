// Na razie wypiszemy tylko info na konsolę
console.log('Hello tasks app.');
