var gulp = require('gulp');

//3/ Taski gulpa to nie konfiguracja, a żywy kod
gulp.task('hello', function() {
  console.log("Hello World!");
});
