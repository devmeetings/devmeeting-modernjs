import './index.html';
import './css/styles.css';
// Pliki z komponentami Reactowymi mają rozszerzenie JSX
import './src/main.jsx';
