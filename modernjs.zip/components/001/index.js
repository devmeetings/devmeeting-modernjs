// Ładujemy główną stronę
import './index.html';
// Globalne style
import './css/styles.css';
// I naszą aplikację
import './src/main.js';
