///<reference path="node_modules/angular2/typings/browser.d.ts"/>

import './index.html';
import './css/styles.css';
import './src/main.ts';
