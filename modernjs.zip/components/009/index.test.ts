///<reference path="./typings/jasmine.d.ts" />
//
import './index.test.html';
import './src/components/Task/Task.spec';
