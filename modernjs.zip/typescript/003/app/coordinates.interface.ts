//4/ Pierwszy interfejs określający właściwości obiektu
export interface Coordinates {
  lat: string;
  lng: string;
}