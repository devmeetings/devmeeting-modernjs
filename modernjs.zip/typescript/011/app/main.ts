//2/ Importuj zależności
import {React} from "./react.class";
import {App} from "./app.class";

/// Renderujemy aplikację
React.render(new App(), document.getElementById("app"));