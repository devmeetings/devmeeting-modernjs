//4/ Najprostrza konfiguracja musi jedynie uwzględniać główny moduł
System.config({
  baseURL: "./",
  defaultJSExtensions: true
});
