//4/ Interfejs określający metodę
export interface Component {
  /// Metoda render musi zwracać string
  render(): string;
}
