System.config({
  defaultJSExtensions: true,
  /// Rezygnujemy z transpilera w przeglądarce na rzecz serwera
  transpiler: false,
  map: {
    "lodash": "/cdn/lodash.js/3.9.3/lodash.js",
  }
});
