System.config({
  defaultJSExtensions: true,
  transpiler: false,
  map: {
    "lodash": "/cdn/lodash.js/3.9.3/lodash.js",
  }
});
