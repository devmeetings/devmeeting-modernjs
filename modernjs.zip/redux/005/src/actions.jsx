//2/ Wydzielamy akcje do osobnego pliku ze stałymi
export const increment = 'INC';
export const decrement = 'DEC';
export const fetchTodosStarted = 'TODOS_FETCH_STARTED';
export const fetchTodosSuccess = 'TODOS_FETCH_SUCCESS';
export const fetchTodosFailure = 'TODOS_FETCH_FAILURE';

