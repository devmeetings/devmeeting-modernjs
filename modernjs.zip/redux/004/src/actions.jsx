//2/ Wydzielamy akcje do osobnego pliku ze stałymi
export const increment = 'INC';
export const decrement = 'DEC';
